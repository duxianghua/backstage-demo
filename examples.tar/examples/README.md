# Example Entities

This is a set of example entities that you can make use of to demonstrate basic
Backstage features.
